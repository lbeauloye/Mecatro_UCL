#ifndef GUI_H_
#define GUI_H_

#include "terasic_includes.h"
//#include "multi_touch2.h"
#include "vip_fr.h"

void GUI(); //MTC2_INFO *pTouch);

#endif /*GUI_H_*/
