
#ifndef AD7843_H_
#define AD7843_H_

void LT24_SPI_Init();
void LT24_SPI_Write(alt_u8 data);
alt_u8 LT24_SPI_Read();

#endif /* AD7843_H_ */
