#include "test.h"

int Test_func(int a){
    return a*2;
}